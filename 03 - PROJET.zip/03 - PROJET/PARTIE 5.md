
## Enoncé

Par ailleurs, AJCFRAME souhaite se doter d’une IHM (Interface Homme Machine) permettant d’ajouter des pièces au sein d’un fichier ‘PROJET.NEWPARTS.KSDS’. Le contenu de ce fichier sera ajouté au sein de la table PARTS. 

Afin de garantir un accès sécurisé, l’utilisateur devra au préalable s’authentifier. Afin de vous faciliter la tâche, vous utiliserez le fichier ‘AJC.EMPLOYE.KSDS’ (le code employé correspondra au login et le prénom de l’employé au mot de passe). 

Seulement une fois authentifié, l’utilisateur sera en mesure de pouvoir ajouter des pièces. 

Afin d’éviter les doublons au sein de CICS, voici la nomenclature imposée : 
X : correspond au nom du groupe 
- Fichier PROJET.NEWPARTS.KSDS ➔ PARTSX 
- Fichier PROJET.EMPLOYE.KSDS ➔ USERSX 
- Vos noms de Mapset(s) et de Map(s) commenceront respectivement par MSX et MAPX 
- Vos noms de transaction(s) commenceront par TX
## Résumé 

Faire une IHM avec authentification de l'utilisateur permettant d'ajouter de nouvelles pièces.

## Choix faits

L'ajout d'une nouvelle pièce dans le fichier KSDS.
2 programmes COBOL : le 1er pour l'authentification, le 2ème pour l'ajout de pièces
2 mapsets à écrire : un pour l'écran d'authentification et un pour l'écran d'ajout de pièces
4 JCL de compilation : 2 pour les programmes COBOL et 2 pour les Mapsets
2 transactions : une pour l'authentification et une pour l'ajout de pièces
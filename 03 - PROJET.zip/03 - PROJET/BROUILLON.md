coquille dans le fichier, taille maxime du fichie new prod est de 50, pas 45

copier api9.source.sql.bddorder
M.11.1

![[Pasted image 20260804125004.png]]